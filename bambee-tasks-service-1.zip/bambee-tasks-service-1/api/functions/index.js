const getTaskById = require('./getTaskById').getById;
const updateTaskById = require('./updateTaskById').updateTaskById;

module.exports = {
    getTaskById,
    updateTaskById
};